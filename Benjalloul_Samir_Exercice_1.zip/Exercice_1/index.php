<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="calcul.php" method="POST">
        <p>1ere Valeur</p>
        <input type="text" name="valeur1">

        <p>2eme Valeur</p>
        <input type="text" name="valeur2"><br></br>

        <input type="submit" value="addition" name="addition"><br></br>
        <input type="submit" value="soustraction" name="soustraction"><br></br>
        <input type="submit" value="Multiplication" name="multiplication"><br></br>
        <input type="submit" value="division" name="division">

    
    </form>



</body>
</html>