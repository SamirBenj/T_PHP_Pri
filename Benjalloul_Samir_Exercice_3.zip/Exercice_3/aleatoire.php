<?php

$i = 0;
$j = 0;
$countSup5 = 0;
$countInf5 = 0;
$nb = 0;
$nbvaleur = isset($_POST['nbvaleur']) ? $_POST['nbvaleur'] : '';

if( isset($_POST['submit'])) {

for($i=1;$i<=$nbvaleur;$i++)
        {
            $nb++;
                $nombre[$i] = rand(0,10);
                //valeur <= 5
                if($nombre[$i] <= 5 ) {
                    $countInf5++;
                }
                //valeur valeurs supérieures strictement à 5
                if($nombre[$i] > 5 ) {
                    $countSup5++;
                }
                echo '<p> valeur '.$nb.' = ' .$nombre[$i].'<p>';
                
        }
    }

echo '<p> nombre de valeurs inférieures ou égales à 5 => '.$countInf5.'</p>' ;

echo '<p> nombre de valeurs supérieures strictement à 5 => '.$countSup5.'</p>';



?>